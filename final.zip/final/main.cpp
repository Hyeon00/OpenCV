//
//  main.cpp
//  final
//
//  Created by 임성현 on 2020/06/20.
//  Copyright © 2020 임성현. All rights reserved.
//

#include <iostream>
#include <opencv2/opencv.hpp>

using namespace std;
using namespace cv;

// 기본 이미지 변수
Mat palette, canvas;
Mat menu2Image, menu1Image;

// 메뉴1 전역변수
vector<Rect> icons;                             // 아이콘 버튼 사각형들
int hue;                                        // hue
int mouse_mode = 0, draw_mode = 0;              // 마우스 상태, 그리기 모드
Point pt1, pt2;                                 // 마우스 이벤트 좌표 값들
Scalar Color(0, 0, 0);                          // 색상변수 - 전역변수 지정
int thickness = 3;                              // 선 굵기 - 전역변수

// 메뉴2 전역변수
vector<Rect> menu2;                             // menu2 버튼 사각형들

Mat readImage();                                // 이미지 불러오기

// 메뉴1 함수

// 메뉴2 함수
int bInsideRect(int x, int y, Rect rect);       // 점이 사각형 안에 있는지 체크
void addNoise(Mat& img, int nNoise);            // 노이즈 추가하는 함수
void onMouse_menu2(int event, int mx, int my, int flag, void* param);

// 메뉴1 헤더파일
#include "menu1.hpp"
#include "icon_flag.hpp"                        // 아이콘 상수 헤더파일
#include "drawPaint.hpp"
#include "menu1Event.hpp"

// 메뉴2 헤더파일
#include "menu2.hpp"
#include "menu2Event.hpp"

int main(int argc, const char * argv[]) {
    // insert code here...
    // 기본 이미지
    palette = Mat(500, 800, CV_8UC3, Scalar(255, 255, 255));
    
    // 메뉴1
    menu1Image = Mat(500, 120, CV_8UC3, Scalar(255, 255, 255));
    
    place_icons(Size(60, 60));                              // 아이콘 배치, 아이콘 크기
    
    Rect last_icon = *(icons.end() - 1);                    // 아이콘 사각형 마지막 원소
    Point start_palette = Point(0, last_icon.br().y + 5);   // 팔레트 시작 위치
    
    icons.push_back(Rect(start_palette, Size(100, 100)));   // 팔레트 사각형 추가
    icons.push_back(Rect(start_palette + Point(105, 0), Size(15, 100)));
                                                            // 색상 인덱스 사각형
    
    create_hueIndex(icons[HUE_IDX]);                        // 팔레트 생성
    create_palette(start_palette.y, icons[PALETTE]);        // 색상 인덱스 생성

    // 메뉴2
    menu2Image = Mat::zeros(500, 400, CV_8UC1);
    menu2Image += 255;                                // 흰 바탕.
    place_menu2(Size(200, 100));                       // 아이콘 배치, 아이콘 크기
    
    // 메뉴1 창을 만들고 마우스 이벤트 추가
    namedWindow("Menu1");
    setMouseCallback("Menu1", onMouse_menu1, &palette);
    
    // 메뉴2 창을 만들고 마우스 이벤트 추가
    namedWindow("Menu2");
    setMouseCallback("Menu2", onMouse_menu2, &palette);

    imshow("Palette", palette);
    imshow("Menu1", menu1Image);
    imshow("Menu2", menu2Image);
    
    int  x = icons[1].br().x;
    Rect canvas_rect(x, 0, palette.cols - x, palette.rows);
    canvas = palette(canvas_rect);
    
    while (1) {
        if (mouse_mode == 1) {                  // 마우스 버튼 떼기
            draw(palette, Color);                 // 원본에 그림
        } else if (mouse_mode == 3) {           // 마우스 드래그
            if (draw_mode == DRAW_BRUSH || draw_mode == ERASE) {
                draw(palette, Color);             // 원본에 그림
            } else {
                draw(palette.clone(), Scalar(200, 200, 200)); // 복사본에 회색으로 그림
            }
        }
        if (waitKey(30) == 27)  break;          // ESC 키 누르면 종료
    }
    
    waitKey();

    return 0;
}

// 이미지 읽어오기.
Mat readImage() {
    Mat I = imread("/Users/seonghyeon/xCode/opencv/opencv/final/image/G.jpg",IMREAD_GRAYSCALE);
    if (I.empty()) {
        cout << "Error opening image" << endl;
        exit(EXIT_FAILURE);
    }
    return I;
}

// 점이 사각형 안에 있는지 체크: 안에 있으면 1, 밖에 있으면 0
int bInsideRect(int x, int y, Rect rect) {
    if (x >= rect.x && x < rect.x + rect.width && y >= rect.y && y < rect.y + rect.height)
        return 1;
    else
        return 0;
}

// 노이즈 추가하는 함수
void addNoise(Mat& img, int nNoise) {
    int nGenPoints = 0;
    while (nGenPoints < nNoise) {
        int x = (int)(((float)rand() / RAND_MAX) * img.cols);
        int y = (int)(((float)rand() / RAND_MAX) * img.rows);
        if (x >= img.cols || y >= img.rows)
            continue;
        if ((float)rand() / RAND_MAX > 0.5)
            img.at<uchar>(y, x) = 0;
        else
            img.at<uchar>(y, x) = 255;
        nGenPoints++;
    }
}

// 마우스 이벤트 핸들러
void onMouse_menu2(int event, int mx, int my, int flag, void* param) {
    /*
    switch (event) {
    case EVENT_LBUTTONDOWN:
        if (bInsideRect(mx, my, rMenu1)) {
            addNoise(image, 100);
            imshow("src", image);
        }
        else if (bInsideRect(mx, my, rMenu2)) {
            putText(image, "This is The final Exam!", Point(100,100), FONT_HERSHEY_SIMPLEX, 1.3, Scalar(255,255,255), 4);
            putText(image, "Add your functions!", Point(100, 200), FONT_HERSHEY_SIMPLEX, 1.3, Scalar(255, 255, 255), 4);
            imshow("src", image);
        }
        break;
    }
    */
}

